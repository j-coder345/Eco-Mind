import React, { useState } from 'react';
import { View, Text, TextInput, Button, ScrollView, StyleSheet, Switch, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

const API_BASE = 'http://localhost:4000';
const OPENAI_API_KEY = 'your-openai-api-key';

const EconoMind = () => {
  const [question, setQuestion] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [supply, setSupply] = useState(100);
  const [demand, setDemand] = useState(100);
  const [price, setPrice] = useState(10);
  const [theme, setTheme] = useState('light');
  const [user, setUser] = useState(null);
  const [aiTutor, setAiTutor] = useState('EconoBot');
  const [auth, setAuth] = useState({ email: '', password: '' });
  const [capital, setCapital] = useState(1000);
  const [units, setUnits] = useState(0);

  const simulateMarket = () => {
    let newPrice = price;
    if (demand > supply) newPrice += 1;
    else if (supply > demand) newPrice -= 1;
    setPrice(Math.max(1, newPrice));
  };

  const askEconoBot = async () => {
    try {
      const res = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: 'gpt-3.5-turbo',
          messages: [{ role: 'user', content: question }]
        },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${OPENAI_API_KEY}`,
          },
        }
      );
      setAiResponse(\`(\${aiTutor}): \${res.data.choices[0].message.content}\`);
    } catch (error) {
      setAiResponse('Error connecting to AI.');
    }
  };

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  const handleLogin = async () => {
    try {
      const res = await axios.post(\`\${API_BASE}/auth/login\`, auth);
      await AsyncStorage.setItem('token', res.data.token);
      setUser({ email: auth.email });
    } catch (err) {
      alert('Login failed');
    }
  };

  const handleSignup = async () => {
    try {
      const res = await axios.post(\`\${API_BASE}/auth/signup\`, auth);
      await AsyncStorage.setItem('token', res.data.token);
      setUser({ email: auth.email });
    } catch (err) {
      alert('Signup failed');
    }
  };

  const playMarketTycoon = () => {
    const productPrice = 10;
    const sellPrice = 12;

    Alert.alert(
      '🧮 Market Tycoon',
      \`Capital: $\${capital}\nUnits: \${units}\nBuy at $\${productPrice} / Sell at $\${sellPrice}\`,
      [
        { text: 'Buy 1 Unit', onPress: () => {
          if (capital >= productPrice) {
            setCapital(capital - productPrice);
            setUnits(units + 1);
          } else alert('Not enough capital!');
        } },
        { text: 'Sell 1 Unit', onPress: () => {
          if (units > 0) {
            setCapital(capital + sellPrice);
            setUnits(units - 1);
          } else alert('No units to sell!');
        } },
        { text: 'Close' },
      ]
    );
  };

  return (
    <ScrollView style={{ padding: 20, backgroundColor: theme === 'light' ? '#f0f4f8' : '#121212' }}>
      <Text style={{ fontSize: 28, fontWeight: 'bold', color: theme === 'light' ? '#000' : '#fff' }}>📊 EconoMind</Text>

      {!user ? (
        <View>
          <TextInput placeholder="Email" onChangeText={text => setAuth({ ...auth, email: text })} />
          <TextInput placeholder="Password" secureTextEntry onChangeText={text => setAuth({ ...auth, password: text })} />
          <Button title="Login" onPress={handleLogin} />
          <Button title="Sign Up" onPress={handleSignup} />
        </View>
      ) : (
        <Text>👤 Welcome, {user.email}</Text>
      )}

      <Switch value={theme === 'dark'} onValueChange={toggleTheme} />

      <Text>Select AI Tutor:</Text>
      <Button title="EconoBot" onPress={() => setAiTutor('EconoBot')} />
      <Button title="MarketMaster AI" onPress={() => setAiTutor('MarketMaster AI')} />
      <TextInput placeholder="Ask your AI tutor..." value={question} onChangeText={setQuestion} />
      <Button title="Ask" onPress={askEconoBot} />
      <Text>{aiResponse}</Text>

      <Text>Supply: {supply} | Demand: {demand} | Price: ${price}</Text>
      <Button title="Increase Demand" onPress={() => setDemand(d => d + 10)} />
      <Button title="Increase Supply" onPress={() => setSupply(s => s + 10)} />
      <Button title="Simulate Market" onPress={simulateMarket} />

      <Button title="Play Market Tycoon" onPress={playMarketTycoon} />
    </ScrollView>
  );
};

export default EconoMind;
