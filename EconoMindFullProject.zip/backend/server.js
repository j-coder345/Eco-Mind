const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const app = express();
const PORT = 4000;
const SECRET = 'econo_secret_key';

app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/economind', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const UserSchema = new mongoose.Schema({ email: String, password: String });
const User = mongoose.model('User', UserSchema);

app.post('/auth/signup', async (req, res) => {
  const { email, password } = req.body;
  const hash = await bcrypt.hash(password, 10);
  const user = new User({ email, password: hash });
  await user.save();
  const token = jwt.sign({ email }, SECRET);
  res.json({ token });
});

app.post('/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  const match = user && await bcrypt.compare(password, user.password);
  if (!match) return res.status(401).json({ error: 'Invalid login' });
  const token = jwt.sign({ email }, SECRET);
  res.json({ token });
});

app.listen(PORT, () => console.log(`Auth server running on http://localhost:${PORT}`));
